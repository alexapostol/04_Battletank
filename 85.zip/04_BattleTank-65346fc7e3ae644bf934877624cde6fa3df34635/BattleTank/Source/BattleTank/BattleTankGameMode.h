// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/GameMode.h"
#include "BattleTankGameMode.generated.h"

/**
 * 
 */
UCLASS()
class BATTLETANK_API ABattleTankGameMode : public AGameMode
{
	GENERATED_BODY()
	
	
	
	
};
