Part of the Complete Unreal Creator course on Udemy, see [here](https://www.udemy.com/unrealcourse?couponCode=GitHubDiscount) for a special GitHub offer. The full course is part of [this](https://www.kickstarter.com/projects/bentristem/learn-to-make-video-games-unreal-developer-course) Kickstarter campaign which was over 1000% funded.

These are just the files from the course, not the actual tutorial videos. This course is exclusively hosted on Udemy.com, and has many hours of high-quality videos.

You're welcome to download, fork or do whatever else legal with all the files!

Enjoy yourself.

Ben Tristem

---
Click [here](https://www.udemy.com/unrealcourse?couponCode=GitHubDiscount) to find out more about the course, and how we build these assets step-by-step.

## Lecture List
* BT01 Intro, Notes & Assets
* BT02 Game Design Document (GDD)
* BT03 Setting Up a GitHub "Repo"
*...
* BT75 Breaking Large Refactors Down (Talking Head)
